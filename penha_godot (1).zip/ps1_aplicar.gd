extends Node3D
## Coloque este script num Node3D que seja pai da rua e do personagem.
## Ao rodar, troca os materiais importados pelo shader PS1, mantendo as texturas.

@export var shader: Shader
@export var resolucao := Vector2(320, 240)

func _ready() -> void:
	if shader == null:
		shader = load("res://ps1.gdshader")
	_converter(self)

func _converter(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		if mi.mesh:
			for i in mi.mesh.get_surface_count():
				var src := mi.get_active_material(i)
				# peças de dupla face (pipas, orelhão) ficam com o material original
				if src is StandardMaterial3D and src.cull_mode == BaseMaterial3D.CULL_BACK:
					var sm := ShaderMaterial.new()
					sm.shader = shader
					sm.set_shader_parameter("albedo_tex", src.albedo_texture)
					sm.set_shader_parameter("tint", src.albedo_color)
					sm.set_shader_parameter("snap_resolution", resolucao)
					mi.set_surface_override_material(i, sm)
	for c in n.get_children():
		_converter(c)
