class_name Pose
extends RefCounted
## Gira ossos em cima da pose que veio no .glb (a "rest" já é a pose sentada/de pé).

static func esqueleto(no: Node) -> Skeleton3D:
	if no is Skeleton3D:
		return no
	if no is MeshInstance3D and (no as MeshInstance3D).skeleton != NodePath():
		var sk = no.get_node_or_null((no as MeshInstance3D).skeleton)
		if sk is Skeleton3D:
			return sk
	var achados := no.find_children("*", "Skeleton3D", true, false)
	if achados.size() > 0:
		return achados[0]
	var p := no.get_parent()
	return p if p is Skeleton3D else null

static func girar(sk: Skeleton3D, osso: String, graus: Vector3) -> void:
	if sk == null:
		return
	var i := sk.find_bone(osso)
	if i < 0:
		return
	var q := Quaternion.from_euler(Vector3(deg_to_rad(graus.x), deg_to_rad(graus.y), deg_to_rad(graus.z)))  # ordem YXZ, igual ao three.js
	sk.set_bone_pose_rotation(i, sk.get_bone_rest(i).basis.get_rotation_quaternion() * q)

## Instancia o protagonista.glb com as animações em loop ("andar", "parado").
static func personagem_animado() -> Node3D:
	var p: Node3D = load("res://modelos/protagonista.glb").instantiate()
	var ap := p.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if ap:
		for nome in ap.get_animation_list():
			ap.get_animation(nome).loop_mode = Animation.LOOP_LINEAR
	return p
