class_name HUD
extends CanvasLayer
## Interface em 320×240: tarjas de cinema, nome da câmera, relógio, linha do ônibus,
## carteira/cesta, aviso de interação e mensagens rápidas.

var tomada: Label
var relogio: Label
var linha: Label
var dinheiro: Label
var aviso: Label
var mensagem: Label
var dica: Label
var _t_msg := 0.0

func _ready() -> void:
	for y in [0.0, 1.0]:
		var barra := ColorRect.new()
		barra.color = Color.BLACK
		barra.anchor_left = 0; barra.anchor_right = 1
		barra.anchor_top = y - (0.125 if y > 0 else 0.0); barra.anchor_bottom = y + (0.0 if y > 0 else 0.125)
		barra.name = "Tarja"
		add_child(barra)
	tomada = _label(Vector2(12, 8), 7, Color(1, 1, 1, 0.7))
	relogio = _label(Vector2(12, 218), 10, Color("f3e6c8"))
	linha = _label(Vector2(0, 220), 8, Color("f0b541"))
	linha.anchor_left = 1; linha.anchor_right = 1; linha.offset_left = -200; linha.offset_right = -10
	linha.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	dinheiro = _label(Vector2(0, 34), 8, Color("f3e6c8"))
	dinheiro.anchor_left = 1; dinheiro.anchor_right = 1; dinheiro.offset_left = -160; dinheiro.offset_right = -8
	dinheiro.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	aviso = _label(Vector2(0, 186), 9, Color.WHITE)
	aviso.anchor_left = 0; aviso.anchor_right = 1; aviso.offset_left = 0; aviso.offset_right = 0
	aviso.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mensagem = _label(Vector2(0, 100), 10, Color("ffd35a"))
	mensagem.anchor_left = 0; mensagem.anchor_right = 1; mensagem.offset_left = 0; mensagem.offset_right = 0
	mensagem.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dica = _label(Vector2(0, 8), 7, Color(1, 1, 1, 0.55))
	dica.anchor_left = 1; dica.anchor_right = 1; dica.offset_left = -160; dica.offset_right = -8
	dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

func _label(pos: Vector2, tamanho: int, cor: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", tamanho)
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_shadow_color", Color.BLACK)
	l.add_theme_constant_override("shadow_offset_x", 1)
	l.add_theme_constant_override("shadow_offset_y", 1)
	add_child(l)
	return l

func msg(texto: String) -> void:
	mensagem.text = texto
	_t_msg = 2.2

func _process(delta: float) -> void:
	if _t_msg > 0.0:
		_t_msg -= delta
		if _t_msg <= 0.0:
			mensagem.text = ""
