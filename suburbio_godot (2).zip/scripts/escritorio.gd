class_name CenaEscritorio
extends Node3D
## Um dia no call center: colegas digitando, supervisor andando no corredor,
## relógio acelerando das 9h às 18h e o protagonista afundando na cadeira.

signal terminou

const DUR := 6.0
var hud: HUD
var T := 0.0
var cam: Camera3D
var colegas: Array = []     # [esqueleto, fase]
var prot: Skeleton3D
var sup: Node3D
var ponteiro_h: Node3D
var ponteiro_m: Node3D
var sx := -6.0
var sd := 1.0
var vel := 1.4
var tomadas := [
	{ nome = "CALL CENTER", de = func(t): return Vector3(7.4 - t * 0.35, 2.35, 5.6), para = func(_t): return Vector3(0.5, 0.9, -0.6) },
	{ nome = "BAIA", de = func(t): return Vector3(1.25 - t * 0.02, 1.55, 0.95), para = func(_t): return Vector3(0.75, 0.95, -0.8) },
	{ nome = "CORREDOR", de = func(_t): return Vector3(-7.4, 1.25, 1.3), para = func(_t): return Vector3(0, 1.1, 1.2) },
	{ nome = "O RELÓGIO", de = func(t): return Vector3(-5.6 + t * 0.08, 1.8, -0.4), para = func(_t): return Vector3(-8.0, 2.1, -1.5) },
]

func _ready() -> void:
	var cena: Node3D = load("res://modelos/escritorio.glb").instantiate()
	add_child(cena)
	PS1.aplicar(cena)
	Ambiente.criar(self, Color("6d8fc0"), Color("e9e3d0"), Color("dcd8c8"), 0.004, Vector3(0.3, 0.9, 0.4))
	for n in cena.find_children("Colega_*", "", true, false):
		colegas.append([Pose.esqueleto(n), randf() * TAU])
	prot = Pose.esqueleto(cena.find_child("Protagonista", true, false))
	ponteiro_h = cena.find_child("PonteiroHora", true, false)
	ponteiro_m = cena.find_child("PonteiroMinuto", true, false)
	# supervisor: o próprio modelo em silhueta, com o ciclo de caminhada do .glb
	sup = Pose.personagem_animado()
	add_child(sup)
	PS1.silhueta(sup, Color("2a2330"))
	(sup.find_child("AnimationPlayer", true, false) as AnimationPlayer).play("andar")
	cam = Camera3D.new()
	cam.near = 0.1
	add_child(cam)
	cam.make_current()
	hud = HUD.new()
	add_child(hud)
	hud.linha.text = "CALL CENTER · CENTRO"
	hud.dica.text = "Enter: pular"

func _unhandled_input(e: InputEvent) -> void:
	if e.is_action_pressed("ui_accept"):
		terminou.emit()

func _process(delta: float) -> void:
	T += delta
	if T >= DUR * 4:
		terminou.emit()
		set_process(false)
		return
	var h := 9.0 + fmod(T, 24.0) / 24.0 * 9.0
	if ponteiro_m: ponteiro_m.rotation.z = -fmod(h, 1.0) * TAU
	if ponteiro_h: ponteiro_h.rotation.z = -(h / 12.0) * TAU
	for c in colegas:
		Pose.girar(c[0], "forearm_L", Vector3(-52 + sin(T * 17 + c[1]) * 5, 0, 0))
		Pose.girar(c[0], "forearm_R", Vector3(-52 + sin(T * 19 + c[1] * 2) * 5, 0, 0))
		Pose.girar(c[0], "head", Vector3(6 + sin(T * 0.7 + c[1]) * 4, sin(T * 0.3 + c[1]) * 10, 0))
	var cansaco: float = min(1.0, (h - 9.0) / 9.0)
	Pose.girar(prot, "forearm_L", Vector3(-52 + sin(T * 16) * 6, 0, 0))
	Pose.girar(prot, "forearm_R", Vector3(-52 + sin(T * 18.5) * 6, 0, 0))
	Pose.girar(prot, "spine", Vector3(8 + cansaco * 10, 0, 0))
	Pose.girar(prot, "head", Vector3(6 + cansaco * 12 + sin(T * 0.9) * 2, -35.0 if sin(T * 0.25) > 0.85 else 0.0, 0))
	sx += sd * vel * delta
	if sx > 6: sx = 6; sd = -1
	if sx < -6: sx = -6; sd = 1
	sup.position = Vector3(sx, 0, 1.25)
	sup.rotation.y = PI / 2 if sd > 0 else -PI / 2
	var s: Dictionary = tomadas[int(T / DUR) % tomadas.size()]
	var t := fmod(T, DUR)
	cam.fov = 50
	cam.look_at_from_position(s.de.call(t), s.para.call(t), Vector3.UP)
	hud.tomada.text = s.nome
	hud.relogio.text = "%02d:%02d" % [int(h), int(fmod(h, 1.0) * 60)]
