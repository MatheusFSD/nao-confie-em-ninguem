class_name CutsceneOnibus
extends Node3D
## Cutscene do ônibus: o ônibus fica parado e a cidade passa por trás.
## Chacoalho, passageiros balançando, protagonista olhando a janela e 4 cortes de câmera de 6 s.

signal terminou

const V := 11.5
const SPAN := 340.0
const DUR := 6.0

var cfg: Dictionary          # preenchido pelo Fluxo antes de entrar na árvore
var hud: HUD
var T := 0.0
var cena: Node3D
var cam: Camera3D
var corpo: Node3D
var movers: Array = []       # [nó, fator de velocidade]
var rodas: Array = []
var pessoas: Array = []      # [esqueleto, sentado?, fase]
var prot: Skeleton3D
var sacolas: Array = []

func _ready() -> void:
	cena = load(cfg.glb).instantiate()
	add_child(cena)
	PS1.aplicar(cena)
	Ambiente.criar(self, cfg.ceu_topo, cfg.ceu_horizonte, cfg.neblina, cfg.densidade, cfg.luz)
	corpo = cena.find_child("Carroceria", true, false)
	for n in cena.find_children("Mover_*", "", true, false):
		movers.append([n, float(String(n.name).split("_")[1]) / 100.0])
	for n in cena.find_children("Roda_*", "", true, false):
		rodas.append(n)
	for n in cena.find_children("Sentado_*", "", true, false):
		pessoas.append([Pose.esqueleto(n), true, randf() * TAU])
	for n in cena.find_children("EmPe_*", "", true, false):
		pessoas.append([Pose.esqueleto(n), false, randf() * TAU])
	prot = Pose.esqueleto(cena.find_child("Protagonista", true, false))
	for i in 3:
		var s := cena.find_child("Sacola_%d" % i, true, false)
		if s:
			s.visible = i < cfg.get("sacolas", 0)
			sacolas.append(s)
	cam = Camera3D.new()
	cam.near = 0.1
	cam.far = 900.0
	add_child(cam)
	cam.make_current()
	hud = HUD.new()
	add_child(hud)
	hud.linha.text = cfg.linha
	hud.dica.text = "Enter: pular"

func _unhandled_input(e: InputEvent) -> void:
	if e.is_action_pressed("ui_accept"):
		terminou.emit()

func _process(delta: float) -> void:
	T += delta
	if T >= DUR * 4:
		terminou.emit()
		set_process(false)
		return
	var dir: float = cfg.dir
	for m in movers:
		var n: Node3D = m[0]
		n.position.x -= dir * V * m[1] * delta
		if n.position.x < -SPAN / 2: n.position.x += SPAN
		if n.position.x > SPAN / 2: n.position.x -= SPAN
	for r in rodas:
		r.rotate_object_local(Vector3.UP, -V / 0.5 * delta)
	# chacoalho: buracos, lombadas e balanço
	var bump := sin(T * 9.1) * 0.012 + pow(max(0.0, sin(T * 1.7)), 12) * 0.05
	var roll := sin(T * 0.9) * 0.012 + sin(T * 2.3) * 0.004
	corpo.position.y = bump
	corpo.rotation = Vector3(roll, 0, sin(T * 1.1) * 0.006)
	for p in pessoas:
		var sway: float = -roll * 57.0 + sin(T * 1.3 + p[2]) * 1.5
		if p[1]:
			Pose.girar(p[0], "spine", Vector3(4, 0, sway * 0.6))
		else:
			Pose.girar(p[0], "hips", Vector3(0, 0, sway))
			Pose.girar(p[0], "spine", Vector3(0, 0, -sway * 0.4))
	if cfg.get("cansado", false):
		Pose.girar(prot, "head", Vector3(10 + bump * 160, -24 + sin(T * 0.2) * 4, 16 - roll * 30))
		Pose.girar(prot, "spine", Vector3(10, 0, 4 - roll * 50))
	else:
		var olhar := -38 + sin(T * 0.35) * 14 + (28.0 if sin(T * 0.13) > 0.8 else 0.0)
		Pose.girar(prot, "head", Vector3(4 + bump * 120, olhar, -roll * 40))
		Pose.girar(prot, "spine", Vector3(4, 0, -roll * 50))
	for i in sacolas.size():
		sacolas[i].rotation.z = -roll * 2 + sin(T * 3 + i) * 0.03
	# câmera
	var tomadas: Array = cfg.tomadas
	var s: Dictionary = tomadas[int(T / DUR) % tomadas.size()]
	var t := fmod(T, DUR)
	var de: Vector3 = s.de.call(t)
	var para: Vector3 = s.para.call(t)
	if not s.mundo:
		de = corpo.to_global(de) + Vector3(0, sin(T * 6.3) * 0.006, 0)
		para = corpo.to_global(para)
	cam.fov = 50.0 if s.mundo else 62.0
	cam.look_at_from_position(de, para, Vector3.UP)
	hud.tomada.text = s.nome
	hud.relogio.text = "%s:%02d" % [cfg.hora, (int(cfg.minuto) + int(T / 10.0)) % 60]
