class_name Ambiente
extends RefCounted
## Cria céu em degradê, neblina e sol para uma cena.

static func criar(pai: Node, topo: Color, horizonte: Color, neblina: Color, densidade: float, dir_luz: Vector3) -> void:
	var env := Environment.new()
	var ceu := ProceduralSkyMaterial.new()
	ceu.sky_top_color = topo
	ceu.sky_horizon_color = horizonte
	ceu.ground_horizon_color = horizonte
	ceu.ground_bottom_color = horizonte.darkened(0.4)
	ceu.sun_angle_max = 8.0
	var sky := Sky.new()
	sky.sky_material = ceu
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.62
	env.fog_enabled = true
	env.fog_light_color = neblina
	env.fog_density = densidade
	env.fog_sky_affect = 0.0
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	var we := WorldEnvironment.new()
	we.environment = env
	pai.add_child(we)
	var sol := DirectionalLight3D.new()
	sol.light_energy = 0.5
	sol.shadow_enabled = false
	pai.add_child(sol)
	sol.look_at_from_position(Vector3.ZERO, -dir_luz.normalized(), Vector3.UP if abs(dir_luz.normalized().y) < 0.99 else Vector3.FORWARD)
