class_name CenaMercado
extends Node3D
## Mercado jogável em 3ª pessoa: pegar itens (vão pra cesta), pagar no caixa, sair pela porta.
## Controles: WASD/setas andam, Shift corre, E/Espaço interage, arrastar o mouse gira a câmera,
## roda aproxima, Q/R giram a câmera pelo teclado.

signal terminou

var estado: Dictionary          # {carteira, comprado} compartilhado com o Fluxo
var hud: HUD
var itens: Dictionary
var spots: Array
var jogador: CharacterBody3D
var modelo: Node3D
var anim: AnimationPlayer
var cam: Camera3D
var yaw := 0.0
var pitch := 0.35
var dist := 3.2
var cesta := {}
var T := 0.0
var lampada: Node3D
var operadora: Skeleton3D
var clientes: Array = []
var andando: Node3D
var ax := 3.2
var ad := 1.0
var andar_atual := ""
var arrastando := false

const TOPO := 3.2

func _ready() -> void:
	var cena: Node3D = load("res://modelos/mercado.glb").instantiate()
	add_child(cena)
	PS1.aplicar(cena)
	Ambiente.criar(self, Color("5d86c4"), Color("e8dcc0"), Color("d9d4c6"), 0.012, Vector3(0.2, 1, 0.3))
	var dados: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://dados/mercado.json"))
	itens = dados.itens
	spots = dados.spots
	# colisão: uma caixa estática por bloco (paredes, gôndolas, caixas, clientes)
	var corpo := StaticBody3D.new()
	add_child(corpo)
	for c in dados.colliders:
		var cs := CollisionShape3D.new()
		var b := BoxShape3D.new()
		b.size = Vector3(c.x1 - c.x0, TOPO, c.z1 - c.z0)
		cs.shape = b
		cs.position = Vector3((c.x0 + c.x1) / 2.0, TOPO / 2.0, (c.z0 + c.z1) / 2.0)
		corpo.add_child(cs)
	lampada = cena.find_child("LampadaPisca", true, false)
	operadora = Pose.esqueleto(cena.find_child("Operadora", true, false))
	for n in cena.find_children("Cliente_*", "", true, false):
		clientes.append(Pose.esqueleto(n))
	andando = Pose.personagem_animado()
	add_child(andando)
	PS1.silhueta(andando, Color("2f2a3a"))
	(andando.find_child("AnimationPlayer", true, false) as AnimationPlayer).play("andar")
	# jogador
	jogador = CharacterBody3D.new()
	var cap := CollisionShape3D.new()
	var forma := CapsuleShape3D.new()
	forma.radius = 0.28
	forma.height = 1.7
	cap.shape = forma
	cap.position.y = 0.85
	jogador.add_child(cap)
	modelo = Pose.personagem_animado()
	jogador.add_child(modelo)
	PS1.aplicar(modelo)
	anim = modelo.find_child("AnimationPlayer", true, false)
	add_child(jogador)
	jogador.position = Vector3(0, 0, 9.4)
	modelo.rotation.y = PI
	cam = Camera3D.new()
	cam.near = 0.05
	cam.fov = 58
	add_child(cam)
	cam.make_current()
	hud = HUD.new()
	add_child(hud)
	hud.linha.text = "MERCADO · MADUREIRA"
	hud.tomada.text = ""
	hud.dica.text = "E: interagir"
	_atualiza_dinheiro()

func _total_cesta() -> int:
	var t := 0
	for k in cesta: t += int(itens[k].preco) * cesta[k]
	return t

func _qtd_cesta() -> int:
	var q := 0
	for k in cesta: q += cesta[k]
	return q

func _atualiza_dinheiro() -> void:
	hud.dinheiro.text = "Carteira: R$ %d\nCesta: %d %s · R$ %d" % [estado.carteira, _qtd_cesta(), "item" if _qtd_cesta() == 1 else "itens", _total_cesta()]

func _spot_perto() -> Dictionary:
	var melhor := {}
	var bd := 1.3
	for s in spots:
		var d := Vector2(s.x - jogador.position.x, s.z - jogador.position.z).length()
		if d < bd:
			bd = d
			melhor = s
	return melhor

func _rotulo(s: Dictionary) -> String:
	match s.kind:
		"item": return "E · Pegar %s · R$ %d" % [itens[s.key].nome, itens[s.key].preco]
		"caixa": return "E · Pagar no caixa"
		_: return "E · Sair do mercado"

func _interagir() -> void:
	var s := _spot_perto()
	if s.is_empty():
		return
	match s.kind:
		"item":
			var it: Dictionary = itens[s.key]
			var livre: int = estado.carteira - _total_cesta()
			if livre >= int(it.preco):
				cesta[s.key] = cesta.get(s.key, 0) + 1
				hud.msg("+ " + it.nome)
			else:
				hud.msg("Não dá: faltam R$ %d" % (int(it.preco) - livre))
		"caixa":
			if cesta.is_empty():
				hud.msg("Cesta vazia")
			else:
				var t := _total_cesta()
				estado.carteira -= t
				for k in cesta: estado.comprado[k] = estado.comprado.get(k, 0) + cesta[k]
				cesta.clear()
				hud.msg("Pago: R$ %d" % t)
		"porta":
			if not cesta.is_empty():
				hud.msg("Passe no caixa antes de sair")
			else:
				terminou.emit()
	_atualiza_dinheiro()

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo and e.physical_keycode in [KEY_E, KEY_SPACE, KEY_ENTER]:
		_interagir()
	elif e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_LEFT:
			arrastando = e.pressed
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed:
			dist = max(1.6, dist * 0.9)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed:
			dist = min(5.5, dist * 1.1)
	elif e is InputEventMouseMotion and arrastando:
		yaw -= e.relative.x * 0.01
		pitch = clamp(pitch + e.relative.y * 0.008, -0.1, 1.2)

func _tecla(k: Key) -> float:
	return 1.0 if Input.is_physical_key_pressed(k) else 0.0

func _physics_process(delta: float) -> void:
	T += delta
	var frente := _tecla(KEY_W) + _tecla(KEY_UP) - _tecla(KEY_S) - _tecla(KEY_DOWN)
	var lado := _tecla(KEY_D) + _tecla(KEY_RIGHT) - _tecla(KEY_A) - _tecla(KEY_LEFT)
	yaw += (_tecla(KEY_Q) - _tecla(KEY_R)) * 1.6 * delta
	var correr := Input.is_physical_key_pressed(KEY_SHIFT)
	var fx := -sin(yaw)
	var fz := -cos(yaw)
	var mv := Vector3(fx * frente - fz * lado, 0, fz * frente + fx * lado)
	var mag: float = min(1.0, mv.length())
	var vel := 1.4 * (1.5 if correr else 1.0)
	if mag > 0.08:
		mv = mv.normalized()
		jogador.velocity = mv * vel * mag
		modelo.rotation.y = lerp_angle(modelo.rotation.y, atan2(mv.x, mv.z), min(1.0, delta * 10.0))
		_toca("andar", (1.5 if correr else 1.0) * max(0.55, mag))
	else:
		jogador.velocity = Vector3.ZERO
		_toca("parado", 1.0)
	jogador.move_and_slide()
	jogador.position.y = 0
	# câmera de 3ª pessoa que encolhe quando bate em parede/gôndola
	var alvo := jogador.position + Vector3(0, 1.35, 0)
	var d := Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch))
	var q := PhysicsRayQueryParameters3D.create(alvo, alvo + d * dist)
	q.exclude = [jogador.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var dd := dist
	if hit:
		dd = max(0.6, alvo.distance_to(hit.position) - 0.2)
	var pos := alvo + d * dd
	pos.y = min(pos.y, TOPO - 0.15)
	cam.look_at_from_position(pos, alvo, Vector3.UP)
	var s := _spot_perto()
	hud.aviso.text = "" if s.is_empty() else _rotulo(s)
	# ambiente
	if lampada: lampada.visible = sin(T * 23) * sin(T * 3.1) < 0.6
	if operadora: Pose.girar(operadora, "forearm_R", Vector3(-50 + sin(T * 4) * 12, 0, 0))
	for i in clientes.size():
		Pose.girar(clientes[i], "head", Vector3(12 + sin(T * 0.5 + i) * 4, sin(T * 0.3 + i * 2) * 25, 0))
	ax += ad * 1.4 * delta
	if ax > 3.3: ax = 3.3; ad = -1
	if ax < -7: ax = -7; ad = 1
	andando.position = Vector3(-0.8, 0, ax)
	andando.rotation.y = 0.0 if ad > 0 else PI
	hud.relogio.text = "15:%02d" % ((5 + int(T / 20.0)) % 60)

func _toca(nome: String, velocidade: float) -> void:
	if andar_atual != nome:
		anim.play(nome, 0.25)
		andar_atual = nome
	anim.speed_scale = velocidade
