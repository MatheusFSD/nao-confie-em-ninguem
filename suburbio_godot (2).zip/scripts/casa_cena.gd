extends CenaCasa
## Cena avulsa da casa (Enter volta ao menu).
func _ready() -> void:
	super._ready()
	terminou.connect(func():
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		get_tree().change_scene_to_file("res://cenas/menu.tscn"))
