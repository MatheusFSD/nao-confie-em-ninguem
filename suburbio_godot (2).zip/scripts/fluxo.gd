class_name Fluxo
extends Node
## Encadeia as cenas:
##   trabalho: ônibus de ida → call center → ônibus de volta → fim
##   mercado:  ônibus de ida → mercado jogável → ônibus de volta (com sacolas) → resumo

@export_enum("trabalho", "mercado") var modo := "trabalho"
@export var carteira_inicial := 80

var estado := { carteira = 80, comprado = {} }
var etapas: Array = []
var i := -1
var atual: Node

const V := 11.5
# câmeras da ida (ônibus indo para a direita) e da volta (indo para a esquerda, mostrando a traseira)
var TOMADAS_IDA := [
	{ nome = "LADO DE FORA", mundo = true, de = func(t): return Vector3(-6 + t * 1.4, 2.1, 9.4), para = func(t): return Vector3(-1.5 + t * 0.8, 1.6, 2.2) },
	{ nome = "CORREDOR", mundo = false, de = func(t): return Vector3(4.1 - t * 0.12, 1.75, -0.05), para = func(_t): return Vector3(-0.55, 1.3, 0.9) },
	{ nome = "JANELA", mundo = false, de = func(t): return Vector3(-1.05 + t * 0.03, 1.66, 0.6), para = func(_t): return Vector3(1.2, 1.35, 3.2) },
	{ nome = "FRENTE", mundo = true, de = func(t): return Vector3(24 - t * 1.1, 0.9, 4.6), para = func(_t): return Vector3(0, 1.7, 2.2) },
]
var TOMADAS_VOLTA := [
	{ nome = "TRASEIRA", mundo = true, de = func(t): return Vector3(15 - t * 0.5, 3.4, 0.2), para = func(_t): return Vector3(1.5, 1.4, -2.2) },
	{ nome = "LADO DE FORA", mundo = true, de = func(t): return Vector3(6 - t * 1.4, 2.1, -9.4), para = func(t): return Vector3(1.5 - t * 0.8, 1.6, -2.2) },
	{ nome = "JANELA", mundo = false, de = func(t): return Vector3(-1.05 + t * 0.03, 1.66, 0.6), para = func(_t): return Vector3(1.2, 1.3, 3.2) },
	{ nome = "INDO EMBORA", mundo = true, de = func(t): return Vector3(9 + t * V, 1.25, -2.9), para = func(_t): return Vector3(0, 1.5, -2.2) },
]
var TOMADAS_SACOLAS := [
	TOMADAS_VOLTA[0],
	{ nome = "SACOLAS", mundo = false, de = func(t): return Vector3(-0.05 - t * 0.02, 1.62, -0.02), para = func(_t): return Vector3(-0.3, 0.98, 0.98) },
	TOMADAS_VOLTA[1], TOMADAS_VOLTA[3],
]

func _cfg(nome: String) -> Dictionary:
	match nome:
		"trabalho_ida": return { glb = "res://modelos/trabalho_ida.glb", dir = 1.0, tomadas = TOMADAS_IDA, hora = "06", minuto = 12, linha = "LINHA 950 · PENHA → CENTRO",
			ceu_topo = Color("33406f"), ceu_horizonte = Color("f4c48c"), neblina = Color("f4c48c"), densidade = 0.0075, luz = Vector3(0.7, 0.45, -0.5) }
		"trabalho_volta": return { glb = "res://modelos/trabalho_volta.glb", dir = -1.0, tomadas = TOMADAS_VOLTA, hora = "18", minuto = 40, linha = "LINHA 950 · CENTRO → PENHA", cansado = true,
			ceu_topo = Color("1d1f44"), ceu_horizonte = Color("ef9a5a"), neblina = Color("d9785c"), densidade = 0.0085, luz = Vector3(-0.8, 0.3, 0.4) }
		"mercado_ida": return { glb = "res://modelos/mercado_ida.glb", dir = 1.0, tomadas = TOMADAS_IDA, hora = "14", minuto = 10, linha = "LINHA 950 · PENHA → MADUREIRA",
			ceu_topo = Color("5d86c4"), ceu_horizonte = Color("e8dcc0"), neblina = Color("e4dccb"), densidade = 0.0065, luz = Vector3(0.5, 0.8, -0.4) }
		_: return { glb = "res://modelos/mercado_volta.glb", dir = -1.0, tomadas = TOMADAS_SACOLAS, hora = "16", minuto = 35, linha = "LINHA 950 · MADUREIRA → PENHA",
			ceu_topo = Color("3d5a9a"), ceu_horizonte = Color("f3c88c"), neblina = Color("efc390"), densidade = 0.0072, luz = Vector3(-0.8, 0.35, 0.4), sacolas = _sacolas() }

func _sacolas() -> int:
	var n := 0
	for k in estado.comprado: n += estado.comprado[k]
	return 0 if n == 0 else min(3, ceili(n / 3.0))

func _ready() -> void:
	estado.carteira = carteira_inicial
	etapas = ["trabalho_ida", "escritorio", "trabalho_volta", "fim"] if modo == "trabalho" else ["mercado_ida", "mercado", "mercado_volta", "fim"]
	_proxima()

func _proxima() -> void:
	if atual:
		atual.queue_free()
		atual = null
	i += 1
	var nome: String = etapas[i]
	match nome:
		"escritorio":
			atual = CenaEscritorio.new()
		"mercado":
			atual = CenaMercado.new()
			atual.estado = estado
		"fim":
			_fim()
			return
		_:
			atual = CutsceneOnibus.new()
			atual.cfg = _cfg(nome)
	atual.terminou.connect(_proxima, CONNECT_ONE_SHOT | CONNECT_DEFERRED)
	add_child(atual)

func _fim() -> void:
	var tela := CanvasLayer.new()
	add_child(tela)
	var fundo := ColorRect.new()
	fundo.color = Color(0.07, 0.055, 0.08)
	fundo.set_anchors_preset(Control.PRESET_FULL_RECT)
	tela.add_child(fundo)
	var l := Label.new()
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 10)
	l.add_theme_color_override("font_color", Color("f3e6c8"))
	var txt := ""
	if modo == "trabalho":
		txt = "FIM DO DIA\n\nMais um dia de trabalho."
	else:
		var itens: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://dados/mercado.json")).itens
		txt = "EM CASA\n\n"
		if estado.comprado.is_empty():
			txt += "Voltou de mãos vazias.\n"
		for k in estado.comprado:
			txt += "%d× %s\n" % [estado.comprado[k], itens[k].nome]
		txt += "\nSobrou R$ %d na carteira." % estado.carteira
	l.text = txt + "\n\nEnter: voltar ao menu"
	tela.add_child(l)

func _unhandled_input(e: InputEvent) -> void:
	if i >= 0 and i < etapas.size() and etapas[i] == "fim" and e.is_action_pressed("ui_accept"):
		get_tree().change_scene_to_file("res://cenas/menu.tscn")
