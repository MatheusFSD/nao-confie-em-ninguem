class_name PS1
extends RefCounted
## Converte os materiais importados dos .glb para o shader PS1 (com ou sem luz, uma ou duas faces).

static var _shaders := {}
static var _mats := {}

static func shader(sem_luz: bool, dupla: bool) -> Shader:
	var key := str(sem_luz) + str(dupla)
	if not _shaders.has(key):
		var code: String = load("res://shaders/ps1.gdshader").code
		var modos := "unshaded" if sem_luz else "diffuse_lambert, specular_disabled"
		modos += ", cull_disabled" if dupla else ", cull_back"
		code = code.replace("diffuse_lambert, specular_disabled, cull_back", modos)
		if sem_luz:
			code = code.replace("ROUGHNESS = 1.0;", "")
		var s := Shader.new()
		s.code = code
		_shaders[key] = s
	return _shaders[key]

static func aplicar(raiz: Node) -> void:
	for n in raiz.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if mi.mesh == null:
			continue
		for i in mi.mesh.get_surface_count():
			var src := mi.get_active_material(i)
			if src is BaseMaterial3D:
				mi.set_surface_override_material(i, converter(src))

static func converter(src: BaseMaterial3D) -> ShaderMaterial:
	if _mats.has(src):
		return _mats[src]
	var m := ShaderMaterial.new()
	m.shader = shader(src.shading_mode == BaseMaterial3D.SHADING_MODE_UNSHADED, src.cull_mode == BaseMaterial3D.CULL_DISABLED)
	m.set_shader_parameter("albedo_tex", src.albedo_texture)
	# o importador de glTF converte a cor de linear para sRGB, mas as cores exportadas já eram sRGB: desfaz a conversão
	m.set_shader_parameter("tint", src.albedo_color.srgb_to_linear() if src.albedo_texture == null else Color.WHITE)
	_mats[src] = m
	return m

## Deixa um personagem inteiro em silhueta (cor chapada, sem luz).
static func silhueta(raiz: Node, cor: Color) -> void:
	var m := ShaderMaterial.new()
	m.shader = shader(true, false)
	m.set_shader_parameter("tint", cor)
	for n in raiz.find_children("*", "MeshInstance3D", true, false):
		(n as MeshInstance3D).material_override = m
