class_name CenaCasa
extends Node3D
## Casa com laje, jogável em primeira pessoa.
## Clique para capturar o mouse (Esc solta). WASD anda, Shift corre, E abre/fecha portas.
## A escada externa tem uma rampa de colisão invisível; a laje tem mureta.

signal terminou

const FL := 0.12      # piso da casa (12 cm acima do quintal)
const HW := 2.9       # altura das paredes
const LJ := 3.08      # topo da laje
const OLHO := 1.58

var hud: HUD
var jogador: CharacterBody3D
var cabeca: Node3D
var cam: Camera3D
var portas: Array = []       # {no, corpo, alvo, aberta}
var ang_x := 0.0
var passo := 0.0

func _ready() -> void:
	var casa: Node3D = load("res://modelos/casa.glb").instantiate()
	add_child(casa)
	PS1.aplicar(casa)
	Ambiente.criar(self, Color("27305a"), Color("f2b27a"), Color("c98a74"), 0.004, Vector3(0.4, 0.85, 0.35))
	var dados: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://dados/casa.json"))
	var mundo := StaticBody3D.new()
	add_child(mundo)
	# paredes, móveis, muros e mureta da laje (caixas exportadas da versão web)
	for c in dados.colisoes:
		_caixa(mundo, Vector3(c[0], c[4], c[2]), Vector3(c[1], c[5], c[3]))
	# pisos: rua/quintal, casa, varanda, laje, patamar da escada
	_caixa(mundo, Vector3(-20, -0.5, -20), Vector3(20, 0, 20))
	_caixa(mundo, Vector3(-5, 0, -6), Vector3(5, FL, 6))
	_caixa(mundo, Vector3(-5.175, 0, 6.075), Vector3(1.075, FL, 7.875))
	_caixa(mundo, Vector3(-5.15, HW, -6.15), Vector3(5.15, LJ, 6.15))
	_caixa(mundo, Vector3(5.15, 0, -5.92), Vector3(6.27, LJ, -3.5))
	# escada: rampa invisível do pé (z = 3,5) até o patamar (z = -3,5); corrimão do lado de fora
	var rampa := CollisionShape3D.new()
	var forma := BoxShape3D.new()
	var comp := Vector2(7.0, LJ).length()
	forma.size = Vector3(1.1, 0.1, comp)
	rampa.shape = forma
	rampa.position = Vector3(5.7, LJ / 2.0 - 0.05, 0.0)
	rampa.rotation.x = atan2(LJ, 7.0)
	mundo.add_child(rampa)
	_caixa(mundo, Vector3(6.25, 0, -5.92), Vector3(6.35, LJ + 1.0, 3.5))
	# rampinhas de 12 cm (o CharacterBody3D não sobe degrau sozinho): entrada da varanda e porta dos fundos
	_rampa(mundo, -3.55, -2.35, 7.875, 8.4, FL)
	_rampa(mundo, -3.45, -2.45, -6.075, -6.6, FL)
	# portas: um corpo animável que gira junto com a folha
	for p in dados.portas:
		var no: Node3D = casa.find_child("Porta_" + p.nome, true, false)
		if no == null:
			continue
		var aabb := _aabb(no)
		var corpo := AnimatableBody3D.new()
		corpo.sync_to_physics = false
		var cs := CollisionShape3D.new()
		var b := BoxShape3D.new()
		b.size = Vector3(maxf(aabb.size.x, 0.06), maxf(aabb.size.y, 0.06), maxf(aabb.size.z, 0.06))
		cs.shape = b
		cs.position = aabb.get_center()
		corpo.add_child(cs)
		corpo.set_meta("porta", portas.size())
		no.add_child(corpo)
		portas.append({ no = no, alvo = float(p.alvo), aberta = false, nome = p.nome })
	# jogador em primeira pessoa
	jogador = CharacterBody3D.new()
	var cap := CollisionShape3D.new()
	var cf := CapsuleShape3D.new()
	cf.radius = 0.26
	cf.height = 1.7
	cap.shape = cf
	cap.position.y = 0.85
	jogador.add_child(cap)
	jogador.floor_max_angle = deg_to_rad(40)
	jogador.floor_snap_length = 0.35
	cabeca = Node3D.new()
	cabeca.position.y = OLHO
	jogador.add_child(cabeca)
	cam = Camera3D.new()
	cam.near = 0.05
	cam.fov = 66
	cabeca.add_child(cam)
	add_child(jogador)
	jogador.position = Vector3(-2.95, 0.05, 12.2)
	cam.make_current()
	hud = HUD.new()
	add_child(hud)
	hud.tomada.text = "CASA"
	hud.relogio.text = "14:20"
	hud.dica.text = "Clique: mouse · Esc: soltar"
	for t in hud.get_children():
		if t is ColorRect: t.visible = false          # sem tarjas de cinema: aqui é jogo
	var mira := ColorRect.new()
	mira.color = Color(1, 1, 1, 0.8)
	mira.size = Vector2(2, 2)
	mira.position = Vector2(159, 119)
	hud.add_child(mira)

func _caixa(pai: Node, a: Vector3, b: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var f := BoxShape3D.new()
	var d := (b - a).abs()
	f.size = Vector3(maxf(d.x, 0.02), maxf(d.y, 0.02), maxf(d.z, 0.02))
	cs.shape = f
	cs.position = (a + b) / 2.0
	pai.add_child(cs)

## Rampa invisível ao longo de z: altura h em z_alto, zero em z_baixo.
func _rampa(pai: Node, x0: float, x1: float, z_alto: float, z_baixo: float, h: float) -> void:
	var cs := CollisionShape3D.new()
	var f := BoxShape3D.new()
	var L := Vector2(z_baixo - z_alto, h).length()
	f.size = Vector3(x1 - x0, 0.04, L)
	cs.shape = f
	cs.position = Vector3((x0 + x1) / 2.0, h / 2.0 - 0.02, (z_alto + z_baixo) / 2.0)
	cs.rotation.x = atan2(h, z_baixo - z_alto)
	pai.add_child(cs)

func _aabb(no: Node3D) -> AABB:
	var total := AABB()
	var primeiro := true
	for m in no.find_children("*", "MeshInstance3D", true, false):
		var mi := m as MeshInstance3D
		var bb := no.global_transform.affine_inverse() * mi.global_transform * mi.get_aabb()
		total = bb if primeiro else total.merge(bb)
		primeiro = false
	return total

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif e is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		jogador.rotate_y(-e.relative.x * 0.0025)
		ang_x = clamp(ang_x - e.relative.y * 0.0025, -1.35, 1.35)
		cabeca.rotation.x = ang_x
	elif e is InputEventKey and e.pressed and not e.echo:
		match e.physical_keycode:
			KEY_ESCAPE: Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			KEY_E: _usar()
			KEY_ENTER: terminou.emit()

func _porta_na_mira() -> int:
	var origem := cam.global_position
	var q := PhysicsRayQueryParameters3D.create(origem, origem - cam.global_basis.z * 2.2)
	q.exclude = [jogador.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit and hit.collider.has_meta("porta"):
		return hit.collider.get_meta("porta")
	return -1

func _usar() -> void:
	var i := _porta_na_mira()
	if i < 0:
		return
	var p: Dictionary = portas[i]
	p.aberta = not p.aberta
	var tw := create_tween()
	tw.tween_property(p.no, "rotation:y", p.alvo if p.aberta else 0.0, 0.45).set_trans(Tween.TRANS_SINE)

func _tecla(k: Key) -> float:
	return 1.0 if Input.is_physical_key_pressed(k) else 0.0

func _physics_process(delta: float) -> void:
	var frente := _tecla(KEY_W) + _tecla(KEY_UP) - _tecla(KEY_S) - _tecla(KEY_DOWN)
	var lado := _tecla(KEY_D) + _tecla(KEY_RIGHT) - _tecla(KEY_A) - _tecla(KEY_LEFT)
	var correr := Input.is_physical_key_pressed(KEY_SHIFT)
	var dir := (jogador.global_basis * Vector3(lado, 0, -frente))
	dir.y = 0
	var vel := 1.4 * (1.6 if correr else 1.0)
	if dir.length() > 0.1:
		dir = dir.normalized()
		passo += delta * (11.0 if correr else 7.5)
	jogador.velocity.x = dir.x * vel if dir.length() > 0.1 else 0.0
	jogador.velocity.z = dir.z * vel if dir.length() > 0.1 else 0.0
	jogador.velocity.y = 0.0 if jogador.is_on_floor() else jogador.velocity.y - 9.8 * delta
	jogador.move_and_slide()
	cabeca.position.y = OLHO + (sin(passo) * 0.03 if dir.length() > 0.1 else 0.0)
	var i := _porta_na_mira()
	if i >= 0:
		var p: Dictionary = portas[i]
		hud.aviso.text = "E · %s %s" % ["Fechar" if p.aberta else "Abrir", "portão" if p.nome == "portao" else "porta"]
	else:
		hud.aviso.text = ""
	var pos := jogador.global_position
	hud.linha.text = _comodo(pos.x, pos.z, pos.y)

func _comodo(x: float, z: float, y: float) -> String:
	if y > 2.5: return "ESCADA" if x > 5 else "LAJE"
	if x > 5.1 and x < 6.3 and z > -5.9 and z < 3.5: return "ESCADA"
	if not (x > -5 and x < 5 and z > -6 and z < 6):
		return "VARANDA" if (z > 6 and x < 1.1 and z < 7.85) else "QUINTAL"
	if z > 0.5 and x < 0.5: return "SALA"
	if z > 1.5 and x > 0.5: return "QUARTO"
	if x > 2.5 and z > -1.5: return "BANHEIRO"
	if x > 0.5 and z < -1.5: return "ÁREA DE SERVIÇO"
	if x > 0.5: return "CORREDOR"
	return "COZINHA"
