class_name CenaLaje
extends Node3D
## Vista da laje: telhados vizinhos e a cidade no horizonte, em 4 estados de degradação.
## Troque o estado por código (`mostrar(dia)`) ou pelas teclas 1–4. Arraste o mouse para olhar, roda aproxima.

signal terminou

@export_enum("normal", "estranha", "chamas", "destruida") var estado := "normal"

const ESTADOS := {
	"normal":    { nome = "DIA 1", rotulo = "NORMAL",    topo = Color("27305a"), horiz = Color("f2b27a"), neblina = Color("c98a74"), dens = 0.0016, luz = Vector3(0.3, 0.35, -0.9) },
	"estranha":  { nome = "DIA 3", rotulo = "ESTRANHA",  topo = Color("1f2a26"), horiz = Color("b8b27a"), neblina = Color("7d8466"), dens = 0.0022, luz = Vector3(-0.3, 0.4, -0.9) },
	"chamas":    { nome = "DIA 5", rotulo = "EM CHAMAS", topo = Color("1a0f12"), horiz = Color("e0642a"), neblina = Color("7a3a2a"), dens = 0.0020, luz = Vector3(0.1, 0.3, -1) },
	"destruida": { nome = "DIA 7", rotulo = "DESTRUÍDA", topo = Color("3d3b3a"), horiz = Color("6b635a"), neblina = Color("5e5750"), dens = 0.0029, luz = Vector3(0.2, 0.8, -0.4) },
}

var hud: HUD
var cam: Camera3D
var mundo: Node3D
var T := 0.0
var yaw := 0.15
var pitch := 0.0
var fov := 60.0
var fov_alvo := 60.0
var arrastando := false
var fogos: Array = []
var fumacas: Array = []      # [grupo, altura total]
var piscas: Array = []

func _ready() -> void:
	cam = Camera3D.new()
	cam.near = 0.1
	cam.far = 3000.0
	add_child(cam)
	cam.make_current()
	hud = HUD.new()
	add_child(hud)
	hud.dica.text = "1–4: dia · Enter: sair"
	mostrar(estado)

func mostrar(est: String) -> void:
	estado = est
	if mundo:
		mundo.queue_free()
	var E: Dictionary = ESTADOS[est]
	mundo = Node3D.new()
	add_child(mundo)
	var cena: Node3D = load("res://modelos/laje_%s.glb" % est).instantiate()
	mundo.add_child(cena)
	PS1.aplicar(cena)
	Ambiente.criar(mundo, E.topo, E.horiz, E.neblina, E.dens, E.luz)
	fogos = cena.find_children("Fogo_*", "", true, false)
	piscas = cena.find_children("LuzPisca_*", "", true, false)
	fumacas.clear()
	for g in cena.find_children("Fumaca_*", "", true, false):
		var n := g.get_child_count()
		var passo: float = (g.get_child(n - 1).position.y - g.get_child(0).position.y) / max(1, n - 1)
		fumacas.append([g, passo * n])
	hud.tomada.text = "LAJE"
	hud.relogio.text = E.nome
	hud.linha.text = E.rotulo

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		match e.physical_keycode:
			KEY_1: mostrar("normal")
			KEY_2: mostrar("estranha")
			KEY_3: mostrar("chamas")
			KEY_4: mostrar("destruida")
			KEY_ENTER, KEY_ESCAPE: terminou.emit()
	elif e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_LEFT: arrastando = e.pressed
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed: fov_alvo = max(15.0, fov_alvo * 0.9)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed: fov_alvo = min(70.0, fov_alvo * 1.1)
	elif e is InputEventMouseMotion and arrastando:
		var k := fov / 60.0 * 0.006
		yaw -= e.relative.x * k
		pitch = clamp(pitch - e.relative.y * k, -0.5, 0.9)

func _process(delta: float) -> void:
	T += delta
	for i in fogos.size():
		var g: Node3D = fogos[i]
		for k in g.get_child_count():
			var c: Node3D = g.get_child(k)
			c.scale = Vector3(0.9 + sin(T * 5 + k + i) * 0.12, 0.75 + abs(sin(T * (7 + k) + i * 3)) * 0.5, 0.9 + sin(T * 5 + k + i) * 0.12)
	for i in fumacas.size():
		var g: Node3D = fumacas[i][0]
		var h: float = fumacas[i][1]
		for k in g.get_child_count():
			var b: Node3D = g.get_child(k)
			b.position.y += delta * 3.0 * (1.0 + k * 0.1)
			if b.position.y > h: b.position.y = 0.0
			var f := b.position.y / h
			b.scale = Vector3.ONE * (0.6 + f * 1.6)
			b.position.x = sin(T * 0.3 + i + k) * f * h * 0.15 + f * h * 0.3
	for i in piscas.size():
		piscas[i].visible = sin(T * (3 + i % 5) + i * 1.7) * sin(T * 0.9 + i) > -0.2
	fov = lerp(fov, fov_alvo, min(1.0, delta * 5.0))
	cam.fov = fov
	var olho := Vector3(0.4, 4.75, 1.2)
	cam.look_at_from_position(olho, olho + Vector3(-sin(yaw) * cos(pitch), sin(pitch), -cos(yaw) * cos(pitch)), Vector3.UP)
