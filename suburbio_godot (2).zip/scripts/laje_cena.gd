extends CenaLaje
## Cena avulsa da laje (volta ao menu ao sair).
func _ready() -> void:
	super._ready()
	terminou.connect(func(): get_tree().change_scene_to_file("res://cenas/menu.tscn"))
