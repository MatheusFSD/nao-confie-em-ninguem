extends Control
## Menu inicial: escolhe qual sequência jogar.

func _ready() -> void:
	var fundo := ColorRect.new()
	fundo.color = Color(0.07, 0.055, 0.08)
	fundo.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(fundo)
	var caixa := VBoxContainer.new()
	caixa.set_anchors_preset(Control.PRESET_CENTER)
	caixa.alignment = BoxContainer.ALIGNMENT_CENTER
	caixa.add_theme_constant_override("separation", 8)
	add_child(caixa)
	var titulo := Label.new()
	titulo.text = "SUBÚRBIO"
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titulo.add_theme_font_size_override("font_size", 16)
	titulo.add_theme_color_override("font_color", Color("f3e6c8"))
	caixa.add_child(titulo)
	for par in [["Ir trabalhar", "res://cenas/dia_de_trabalho.tscn"], ["Ir ao mercado", "res://cenas/ida_ao_mercado.tscn"], ["Subir na laje", "res://cenas/laje.tscn"]]:
		var b := Button.new()
		b.text = par[0]
		b.add_theme_font_size_override("font_size", 10)
		b.pressed.connect(func(): get_tree().change_scene_to_file(par[1]))
		caixa.add_child(b)
	var ajuda := Label.new()
	ajuda.text = "Cutscenes: Enter pula\nMercado: WASD · Shift · E · mouse"
	ajuda.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ajuda.add_theme_font_size_override("font_size", 7)
	ajuda.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	caixa.add_child(ajuda)
	caixa.get_child(1).grab_focus()
	caixa.position -= caixa.get_combined_minimum_size() / 2
