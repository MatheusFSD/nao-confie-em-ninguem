# Subúrbio PS1 — projeto Godot 4.3

Abra a pasta no **Godot 4.3** (ou mais novo) e aperte **F5**. Na primeira abertura o Godot importa os modelos (leva alguns segundos).

## O que tem
- **Menu** (`cenas/menu.tscn`): escolhe entre *Ir trabalhar* e *Ir ao mercado*.
- **Dia de trabalho** (`cenas/dia_de_trabalho.tscn`): ônibus de ida → call center → ônibus de volta → fim.
- **Ida ao mercado** (`cenas/ida_ao_mercado.tscn`): ônibus de ida → mercado jogável → ônibus de volta com sacolas → resumo das compras.
- **Laje** (`cenas/laje.tscn`): a "janela" do jogo. Vista do alto da casa, com os telhados vizinhos e a cidade no horizonte em 4 estados:
  `normal` (dia 1), `estranha` (dia 3), `chamas` (dia 5) e `destruida` (dia 7). Teclas **1–4** trocam; arrastar olha em volta; roda aproxima.
  No seu jogo, instancie `CenaLaje` e chame `mostrar("chamas")` conforme o dia. O bairro é o mesmo nos 4 arquivos: só a degradação muda.

Nas cutscenes, **Enter** pula. No mercado: **WASD/setas** andam, **Shift** corre, **E/Espaço** interage, **arrastar o mouse** gira a câmera, **roda** aproxima, **Q/R** giram a câmera.

## Pastas
- `modelos/` — cenários exportados (`trabalho_ida`, `trabalho_volta`, `escritorio`, `mercado_ida`, `mercado_volta`, `mercado`) e o `protagonista.glb` (com as animações `andar` e `parado`).
- `dados/mercado.json` — colisões, pontos de interação e a tabela de itens/preços do mercado. **Para mudar preço ou nome de item, edite aqui.**
- `shaders/ps1.gdshader` — vértices tremendo + textura afim.
- `scripts/`
  - `fluxo.gd` — encadeia as etapas; aqui ficam os horários, linhas de ônibus, cores de céu/neblina e as 4 câmeras de cada cutscene. `carteira_inicial` é exportado (aparece no Inspector).
  - `cutscene_onibus.gd` — cidade passando, chacoalho, passageiros balançando, protagonista olhando a janela.
  - `escritorio.gd` — colegas digitando, supervisor andando, relógio 9h→18h.
  - `mercado.gd` — jogador, câmera, cesta, caixa e porta. Sinal `terminou` ao sair.
  - `ps1.gd` — converte os materiais dos .glb para o shader PS1 e cria silhuetas.
  - `pose.gd` — gira ossos em cima da pose que veio no .glb.
  - `ambiente.gd` — céu, neblina e sol. `hud.gd` — tarjas de cinema e textos.

## Laje: o que é animado
Nos `laje_*.glb`, o script procura pelos nomes: `Fogo_*` (chamas tremendo), `Fumaca_*` (bolas de fumaça subindo e voltando),
`LuzPisca_*` (luzes falhando) e `Vulto_*` (as figuras). O resto da cidade está juntado em poucas malhas (`Cidade_*`), uma por cor.

## Como o ônibus "anda"
O ônibus fica parado; tudo que tem nome começando com `Mover_` passa por trás e dá a volta
(o número no nome é o fator de velocidade ×100: morros usam 8, carros na contramão 230).

## Dicas
- Resolução interna 320×240 esticada para 1280×960 (Configurações do Projeto → Display → Window).
- A geração automática de LOD foi desligada nos .glb (arquivos `.import`) para não trocar a malha low poly por versões simplificadas.
- Tudo que for muito comprido (rua, meio-fio, fiação) está subdividido: com vértice tremendo, triângulo gigante dá problema.
- Para ligar o fim da cutscene a outra cena do seu jogo, conecte o sinal `terminou` de cada etapa ou troque a lista `etapas` em `fluxo.gd`.
